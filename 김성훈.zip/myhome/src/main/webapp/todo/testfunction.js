document.querySelector('#findBtn').addEventListener('click',function(){
	let find =document.querySelector('#keyword').value;
	

	let keyword = document.querySelectorAll("span");
	keyword.forEach(function(span){
		
		if(span.innerText==find){
			console.log(span.innerText);
			document.querySelector("span").remove();
			document.querySelector('#remainCount').remove();
		}
		
	}
	)
	
	
});