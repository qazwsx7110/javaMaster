
document.addEventListener("DOMContentLoaded",function(){
let show =document.querySelector('#show');
show.appendChild(svc.makeTable());
	document.querySelector('#show>table').appendChild(svc.makeHeader());
	document.querySelector('#show>table').appendChild(svc.makeBody());
});

function initForm(){
	
	let show=document.createElement('#show');
	show.appendChild(svc.makeTable());
	document.querySelector('#show>table').appendChild(svc.makeHeader());
	document.querySelector('#show>table').appendChild(svc.makeBody());
}


const svc={
	makeTable:function(){
		let tbl=document.createElement('table');
		tbl.setAttribute('border',"2");
		return tbl;
	},
	makeHeader:function(){
		const days = ['sun','Mon','Tue','wed','Thr','Fri','Sat'];
	    let thd =document.createElement('thead');
	    let tr =document.createElement('th');
	    days.forEach(function(day){
			let th = document.createElement('th');
			th.innerHTML=day;
			tr.appendChild(th);
			
		});
	    thd.appendChild(tr);
	    return thd;
	},
	
	makeHeader2:function(){
			const days = ['sun','Mon','Tue','wed','Thr','Fri','Sat'];
			let tr=days.reduce((acc,curval)=>{
				
				let th = document.createElement('th');
				th.innerHTML=curVal;
				tr.appendChild(th);
			
				return acc;
			},document.createElement('tr'));
            let thd = document.createElement('thead');
            thd.appendChild(tr);
            return thd;	
		},
		
	makeBody:function(){
		let thd =document.createElement('tbody');
		for(let d=1;d<=7;d++){
			
		let tr =document.createElement('tr');
		let td = document.createElement('td');			
		td.innerHTML=d;
		tr.appendChild(td);
		}
		
		thd.appendChild(tr);
		
		
		
		return thd;
	}
}