const xhtp= new XMLHttpRequest();
//xhtp.open('get','../empList.json');
xhtp.open('get','fruit.html');
xhtp.send();
xhtp.onload=function(){
	//let jsonObj=JSON.parse(xhtp.responseText);
	//console.log(jsonObj);
	document.querySelector("body").innerHTML=xhtp.responseText;
	
	
}