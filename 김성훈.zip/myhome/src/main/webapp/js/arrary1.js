empList.forEach((item,idx)=>{
	if(item.first_name.indexOf('C')>=0){
		console.log(item);
	}
});

let newAry = empList.filter((item,idx,ary)=>{
	return (idx+1)==ary.length;
	
});

newAry = empList.map((item,idx,ary)=>{
	const obj={
		no:item.id,
		name:item.first_name+"-"+item.last_name,
	    email:item.email
	}
	return obj;
	
})
console.log(newAry);

let result = empList.reduse((acc,curVal)=>{
	if(curVal.gender=='male'){
		acc.push(curVal);
		
	}
	return acc;
	
},[]);
console.log(result);


const array1 = [1,2,3,4];
const initialValue = 0;
const sumWithInitial = array1.reduce(function(acc,currentValue){
	console.log(`acc=>${acc},currentValue=>${currentValue}`);
	return acc>currentValue?acc:currentValue;
},initialValue);
console.log(sumWithInitial);

console.log("abcde".indexOf("k"));
console.log([1,2,3,4,5].indexOf(3));

let genderAry=[];

empList.forEach();
console.log(genderAry);

