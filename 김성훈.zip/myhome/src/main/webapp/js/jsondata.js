const employees=[{"id":1,"first_name":"Laurie","last_name":"Cleveland","email":"lcleveland0@netscape.com","gender":"Male"},
{"id":2,"first_name":"Petronilla","last_name":"Athow","email":"pathow1@slate.com","gender":"Genderfluid"},
{"id":3,"first_name":"Vail","last_name":"Coneybeare","email":"vconeybeare2@merriam-webster.com","gender":"Male"},
{"id":4,"first_name":"Selle","last_name":"Chittey","email":"schittey3@admin.ch","gender":"Non-binary"},
{"id":5,"first_name":"Sergent","last_name":"Habert","email":"shabert4@51.la","gender":"Male"},
{"id":6,"first_name":"Ursola","last_name":"Turpin","email":"uturpin5@cdbaby.com","gender":"Female"},
{"id":7,"first_name":"Gerome","last_name":"Edgeson","email":"gedgeson6@github.io","gender":"Male"},
{"id":8,"first_name":"Berte","last_name":"Lashmar","email":"blashmar7@spotify.com","gender":"Female"},
{"id":9,"first_name":"Felecia","last_name":"Birds","email":"fbirds8@ed.gov","gender":"Polygender"},
{"id":10,"first_name":"Binnie","last_name":"Deeble","email":"bdeeble9@telegraph.co.uk","gender":"Female"},
{"id":11,"first_name":"Fletcher","last_name":"Dutnall","email":"fdutnalla@printfriendly.com","gender":"Male"},
{"id":12,"first_name":"Fidole","last_name":"Wanell","email":"fwanellb@wordpress.org","gender":"Male"},
{"id":13,"first_name":"Anestassia","last_name":"McFarland","email":"amcfarlandc@indiatimes.com","gender":"Female"},
{"id":14,"first_name":"Kandy","last_name":"Hardwell","email":"khardwelld@ted.com","gender":"Female"},
{"id":15,"first_name":"Bert","last_name":"Stower","email":"bstowere@utexas.edu","gender":"Male"},
{"id":16,"first_name":"Sim","last_name":"Christene","email":"schristenef@edublogs.org","gender":"Male"},
{"id":17,"first_name":"Abey","last_name":"Cusiter","email":"acusiterg@theglobeandmail.com","gender":"Male"},
{"id":18,"first_name":"Mabelle","last_name":"Casina","email":"mcasinah@china.com.cn","gender":"Female"},
{"id":19,"first_name":"Evy","last_name":"Bartram","email":"ebartrami@unc.edu","gender":"Female"},
{"id":20,"first_name":"Olag","last_name":"Parlet","email":"oparletj@privacy.gov.au","gender":"Male"}]

console.log(employees);
const empList = JSON.parse(employees);
console.log(empList);