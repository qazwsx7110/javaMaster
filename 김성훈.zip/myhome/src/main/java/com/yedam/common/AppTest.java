package com.yedam.common;

import java.util.List;

import com.yedam.dao.EmpDAO;
import com.yedam.vo.EmpVo;

public class AppTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EmpDAO edao =new EmpDAO();
		List<EmpVo> list = edao.selectList();
		for(EmpVo vo: list) {
			System.out.println(vo.toString());
		}
		
		
		EmpVo evo = new EmpVo();
		
		evo.setEmpName("fwf444");
		evo.setEmpPhone("08-1234-2234");
		evo.setEmail("fewefw");
		evo.setHireDate("23/04/23");
		evo.setSalary(5000);
		evo.setEmpNo(23);
		
		
		edao.updateEmp(evo);
		
		
	}

}
