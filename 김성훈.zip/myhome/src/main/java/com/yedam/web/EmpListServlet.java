package com.yedam.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yedam.dao.EmpDAO;
//웹프로그램->url실행->서블릿(java)

@WebServlet("/empList.action")
public class EmpListServlet extends HttpServlet {

	@Override
	protected void service(HttpServletRequest request,HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html;charset=utf-8");
		
		PrintWriter out = response.getWriter();
				
		EmpDAO edao = new EmpDAO();
		List<Map<String,Object>> list = edao.empList();
		for(Map<String,Object> map:list) {
			
			
			out.println(map.get("사원번호"));
			out.println(map.get("사원명"));
		}
		
	}
}
