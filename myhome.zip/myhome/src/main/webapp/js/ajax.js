/*
* ajax.js (Asynchronous JavaScript and XML)
*/

setTimeout(function() {
	console.log("step 1");
}, 1000);

setTimeout(function() {
	console.log("step 2");
}, 3000);

setTimeout(function() {
	console.log("step 3");
}, 2000);

